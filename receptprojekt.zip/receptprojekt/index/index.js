let currentUser = null;
const authSection = document.getElementById("authSection");
const loginBox = document.getElementById("loginBox");
const registerBox = document.getElementById("registerBox");
const userSection = document.getElementById("userSection");
const userHeader = document.getElementById("userHeader");
const myRecipesBlock = document.getElementById("myRecipesBlock");
const recipesColumn = document.getElementById("recipesColumn");
const userRecipes = document.getElementById("userRecipes");
const publicRecipes = document.getElementById("publicRecipes");
const message = document.getElementById("message");

function updateLayout(loggedIn) {
    authSection.hidden = loggedIn;
    userSection.hidden = !loggedIn;
    userHeader.hidden = !loggedIn;
    myRecipesBlock.hidden = !loggedIn;
    recipesColumn.className = loggedIn ? "col-12 col-lg-8" : "col-12";
}

// Bejeletkezés és Regisztráció között vált
document.getElementById("showRegisterLink").onclick = (e) => {
    e.preventDefault();
    loginBox.hidden = true;
    registerBox.hidden = false;
    message.textContent = "";
};

document.getElementById("showLoginLink").onclick = (e) => {
    e.preventDefault();
    registerBox.hidden = true;
    loginBox.hidden = false;
    message.textContent = "";
};

function createRecipeCard(recipe, editable = false) {
    const column = document.createElement("div");
    column.className = "col-12 col-sm-6 col-xl-4";

    const card = document.createElement("div");
    card.className = "recipe";

    if (recipe.image) {
        const img = document.createElement("img");
        img.src = recipe.image;
        img.onerror = () => img.style.display = "none";
        card.appendChild(img);
    }

    const title = document.createElement("h3");
    title.textContent = recipe.title;
    card.appendChild(title);

    const fields = [
        ["Étel neve", "title"],
        ["Kategória", "category", ["Leves", "Főétel", "Desszert", "Saláta", "Reggeli"]],
        ["Elkészítési idő", "prep_time"],
        ["Nehézség", "difficulty", ["Könnyű", "Közepes", "Nehéz"]],
        ["Hozzávalók", "ingredients"],
        ["Kép URL-je", "image"]
    ];

    fields.slice(1, 5).forEach(([label, key]) => {
        const value = recipe[key];
        if (value) {
            const p = document.createElement("p");
            p.textContent = label + ": " + value;
            card.appendChild(p);
        }
    });

    if (editable) {
        const status = document.createElement("small");
        status.className = recipe.isPublic ? "text-success" : "text-muted";
        status.textContent = recipe.isPublic ? "Publikus recept" : "Privát recept";
        card.appendChild(status);

        const buttons = document.createElement("div");
        buttons.className = "recipe-buttons";

        const edit = document.createElement("button");
        edit.type = "button";
        edit.className = "btn btn-sm btn-outline-secondary";
        edit.textContent = "Szerkesztés";

        edit.onclick = () => {
            card.innerHTML = "";
            const inputs = {};

            fields.forEach(([label, key, options]) => {
                let fieldEl;

                if (options) {
                    fieldEl = document.createElement("select");
                    fieldEl.className = "form-select mb-2";
                    options.forEach(opt => {
                        const option = document.createElement("option");
                        option.value = opt;
                        option.textContent = opt;
                        fieldEl.appendChild(option);
                    });
                    fieldEl.value = recipe[key] || options[0];
                } else {
                    fieldEl = document.createElement("input");
                    fieldEl.className = "form-control mb-2";
                    fieldEl.placeholder = label;
                    fieldEl.value = recipe[key] || "";
                }

                inputs[key] = fieldEl;
                card.appendChild(fieldEl);
            });

            const publicSelect = document.createElement("select");
            publicSelect.className = "form-select mb-2";
            publicSelect.innerHTML = `
                <option value="1">Publikus</option>
                <option value="0">Privát</option>
            `;
            publicSelect.value = recipe.isPublic;
            card.appendChild(publicSelect);

            const controls = document.createElement("div");
            controls.className = "recipe-buttons";

            const save = document.createElement("button");
            save.type = "button";
            save.className = "btn btn-sm btn-green";
            save.textContent = "Mentés";

            save.onclick = () => {
                fetch(`/api/users/recipes/${currentUser.id}/${recipe.id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        title: inputs.title.value,
                        category: inputs.category.value,
                        prep_time: inputs.prep_time.value,
                        difficulty: inputs.difficulty.value,
                        ingredients: inputs.ingredients.value,
                        image: inputs.image.value,
                        isPublic: Number(publicSelect.value)
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.message == "Recipe updated") {
                        loadUserRecipes();
                        loadPublicRecipes();
                    } else {
                        alert("Nem sikerült a módosítás!");
                    }
                });
            };

            const cancel = document.createElement("button");
            cancel.type = "button";
            cancel.className = "btn btn-sm btn-outline-secondary";
            cancel.textContent = "Mégse";
            cancel.onclick = loadUserRecipes;

            controls.append(save, cancel);
            card.appendChild(controls);
        };

        const del = document.createElement("button");
        del.type = "button";
        del.className = "btn btn-sm btn-outline-danger";
        del.textContent = "Törlés";

        del.onclick = () => {
            if (confirm("Biztosan törlöd ezt a receptet?")) {
                fetch(`/api/users/recipes/${currentUser.id}/${recipe.id}`, {
                    method: "DELETE"
                })
                .then(() => {
                    loadUserRecipes();
                    loadPublicRecipes();
                });
            }
        };
        buttons.append(edit, del);
        card.appendChild(buttons);
    }
    column.appendChild(card);
    return column;
}

// Publikus receptek betöltése
function loadPublicRecipes() {
    fetch("/api/recipes")
        .then(res => res.json())
        .then(data => {
            publicRecipes.innerHTML = "";
            data.forEach(recipe => {
                publicRecipes.appendChild(createRecipeCard(recipe));
            });
        });
}

// Saját receptek betöltése
function loadUserRecipes() {
    fetch(`/api/users/recipes/${currentUser.id}`)
        .then(res => res.json())
        .then(data => {
            userRecipes.innerHTML = "";
            data.forEach(recipe => {
                userRecipes.appendChild(createRecipeCard(recipe, true));
            });
        });
}

// Regisztráció
document.getElementById("registerForm").onsubmit = (e) => {
    e.preventDefault();

    fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: document.getElementById("regUsername").value,
            email: document.getElementById("regEmail").value,
            password: document.getElementById("regPassword").value
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.id) {
            message.textContent = "Sikeres regisztráció! Most már bejelentkezhetsz.";
            message.style.color = "green";
            e.target.reset();
            registerBox.hidden = true;
            loginBox.hidden = false;
        } else {
            message.textContent = data.message || "Sikertelen regisztráció!";
            message.style.color = "red";
        }
    })
    .catch(() => {
        message.textContent = "Hiba történt a regisztráció során!";
        message.style.color = "red";
    });
};

// Bejelentkezés
document.getElementById("loginForm").onsubmit = (e) => {
    e.preventDefault();

    fetch("/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: document.getElementById("loginEmail").value,
            password: document.getElementById("loginPassword").value
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.id) {
            currentUser = data;
            updateLayout(true);

            document.getElementById("welcome").textContent = "Szia, " + data.username + "!";

            e.target.reset();
            message.textContent = "";

            loadUserRecipes();
        } else {
            message.textContent = "Hibás e-mail cím vagy jelszó!";
            message.style.color = "red";
        }
    });
};

// Új recept hozzáadása
document.getElementById("recipeForm").onsubmit = (e) => {
    e.preventDefault();

    fetch("/api/users/recipes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            title: document.getElementById("title").value,
            category: document.getElementById("category").value,
            prep_time: document.getElementById("prepTime").value,
            difficulty: document.getElementById("difficulty").value,
            ingredients: document.getElementById("ingredients").value,
            image: document.getElementById("image").value,
            isPublic: Number(document.getElementById("isPublic").value),
            userId: currentUser.id
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.message == "Recipe saved") {
            e.target.reset();
            message.textContent = "Sikeresen hozzáadtad a receptet!";
            message.style.color = "green";

            loadUserRecipes();
            loadPublicRecipes();
        } else {
            message.textContent = "Nem sikerült a mentés!";
            message.style.color = "red";
        }
    });
};

// Kijelentkezés
document.getElementById("logoutButton").onclick = () => {
    currentUser = null;
    clearForms();
    userRecipes.innerHTML = "";
    message.textContent = "";
    registerBox.hidden = true;
    loginBox.hidden = false;
    updateLayout(false);
    loadPublicRecipes();
};

function clearForms() {
    document.querySelectorAll("form").forEach(form => form.reset());
}

clearForms();
loadPublicRecipes();