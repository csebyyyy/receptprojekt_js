import express from "express";
import bcrypt from "bcrypt";
import * as dbRecipes from "./data/dbRecipes.js";
import * as dbUsers from "./data/dbUsers.js";

const app = express();
const PORT = 3300;

app.use(express.json());
app.use(express.static("index"));

app.get("/api/recipes", (req, res) => {
    const recipes = dbRecipes.GetAllPublicRecipes();
    res.status(200).json(recipes);
});

app.get("/api/recipes/:id", (req, res) => {
    const recipe = dbRecipes.GetPublicRecipeById(Number(req.params.id));
    if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
    }
    res.status(200).json(recipe);
});

// Regisztráció
app.post("/api/users", async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        return res.status(400).json({ message: "Missing data" });
    }
    try {
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(password, salt);
        const saved = dbUsers.SaveUser(username, email, hashedPassword);
        res.status(201).json({ id: saved.lastInsertRowid, username, email });
    } catch (err) {
        console.error("Regisztrációs hiba:", err.message);
        res.status(400).json({ message: "A felhasználónév vagy az e-mail cím már foglalt!" });
    }
});

// Bejelentkezés
app.post("/api/users/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: "Missing data" });
    }
    const user = dbUsers.GetUserByEmail(email);
    if (!user) {
        return res.status(404).json({ message: "User not found" });
    }
    const hashedPw = dbUsers.GetPwById(user.id);
    if (!await bcrypt.compare(password, hashedPw)) {
        return res.status(400).json({ message: "Invalid password" });
    }
    res.status(200).json({ id: user.id, username: user.username, email: user.email });
});

// Saját receptek lekérése
app.get("/api/users/recipes/:userId", (req, res) => {
    const recipes = dbRecipes.GetAllUserRecipes(Number(req.params.userId));
    res.status(200).json(recipes);
});

// Új recept mentése
app.post("/api/users/recipes", (req, res) => {
    const { title, category, prep_time, difficulty, ingredients, isPublic, userId, image } = req.body;
    if (!title || !category || !prep_time || !difficulty || !ingredients || userId == null) {
        return res.status(400).json({ message: "Missing data" });
    }
    dbRecipes.SaveUserRecipe(title,category,prep_time,difficulty,ingredients,Number(isPublic),Number(userId),image || "");
    res.status(201).json({ message: "Recipe saved" });
});

// Saját recept módosítása
app.put("/api/users/recipes/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);
    const existing = dbRecipes.GetUserRecipeById(userId, id);
    if (!existing) {
        return res.status(404).json({ message: "Recipe not found" });
    }
    const { title, category, prep_time, difficulty, ingredients, isPublic, image } = req.body;
    if (!title || !category || !prep_time || !difficulty || !ingredients) {
        return res.status(400).json({ message: "Missing data" });
    }
    dbRecipes.UpdateUserRecipe(id,title,category,prep_time,difficulty,ingredients,Number(isPublic),userId,image || "");
    res.status(200).json({ message: "Recipe updated" });
});

// Saját recept törlése
app.delete("/api/users/recipes/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);
    const existing = dbRecipes.GetUserRecipeById(userId, id);
    if (!existing) {
        return res.status(404).json({ message: "Recipe not found" });
    }
    dbRecipes.DeleteUserRecipe(userId, id);
    res.status(200).json({ message: "Recipe deleted" });
});

app.listen(PORT, () => {
    console.log(`Runs on http://localhost:${PORT}`);
});