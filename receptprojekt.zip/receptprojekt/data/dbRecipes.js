import Database from "better-sqlite3";

const db = new Database("./data/recipes.db");

db.exec(`CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    prep_time TEXT NOT NULL,
    difficulty TEXT NOT NULL,
    ingredients TEXT NOT NULL,
    isPublic INTEGER NOT NULL DEFAULT 1,
    userId INTEGER NOT NULL,
    image TEXT)
`);

const count = db.prepare(`SELECT COUNT(*) AS count FROM recipes`).get().count;
if (count === 0) {
  const insert = db.prepare(`INSERT INTO recipes (title, category, prep_time, difficulty, ingredients, isPublic, userId, image) VALUES (?,?,?,?,?,?,?,?)`);
  insert.run("Klasszikus Palacsinta", "Desszert", "30 perc", "Könnyű", "Liszt, tojás, tej, szénsavas víz, csipet só, olaj", 1, 0, "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=600");
  insert.run("Gulyásleves", "Leves", "90 perc", "Közepes", "Marhalábszár, vöröshagyma, burgonya, sárgarépa, pirospaprika, kömény", 1, 0, "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=600");
  insert.run("Carbonara Spagetti", "Főétel", "25 perc", "Könnyű", "Spagetti tészta, guanciale vagy bacon, tojássárgája, parmezán, fekete bors", 1, 0, "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=600");
}

export const GetAllPublicRecipes = () => db.prepare(`SELECT * FROM recipes WHERE isPublic = 1`).all();
export const GetPublicRecipeById = (id) => db.prepare(`SELECT * FROM recipes WHERE id = ? AND isPublic = 1`).get(id);
export const GetAllUserRecipes = (userId) => db.prepare(`SELECT * FROM recipes WHERE userId = ?`).all(userId);
export const GetUserRecipeById = (userId, id) => db.prepare(`SELECT * FROM recipes WHERE userId = ? AND id = ?`).get(userId, id);
export const SaveUserRecipe = (title, category, prep_time, difficulty, ingredients, isPublic, userId, image) => db.prepare(`INSERT INTO recipes (title, category, prep_time, difficulty, ingredients, isPublic, userId, image) VALUES (?,?,?,?,?,?,?,?)`).run(title, category, prep_time, difficulty, ingredients, isPublic, userId, image);
export const UpdateUserRecipe = (id, title, category, prep_time, difficulty, ingredients, isPublic, userId, image) => db.prepare(`UPDATE recipes SET title = ?, category = ?, prep_time = ?, difficulty = ?, ingredients = ?, isPublic = ?, image = ? WHERE id = ? AND userId = ?`).run(title, category, prep_time, difficulty, ingredients, isPublic, image, id, userId);
export const DeleteUserRecipe = (userId, id) => db.prepare(`DELETE FROM recipes WHERE userId = ? AND id = ?`).run(userId, id);